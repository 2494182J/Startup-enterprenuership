from django.apps import AppConfig


class DescribeConfig(AppConfig):
    name = 'describe'
