from django.contrib import admin
from .models import DescribePost
admin.site.register(DescribePost)
# Register your models here.
