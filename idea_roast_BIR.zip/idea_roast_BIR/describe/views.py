from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
# Create your views here.
from comment.models import Comment
from . import models
from .models import DescribePost
from django.contrib.auth.models import User
from django.core.paginator import Paginator

import describe


def describeIdea_list(request):
    if request.GET.get('order') == 'total_views':
        describeIdea_list = DescribePost.objects.all().order_by('-total_views')
        order = 'total_views'
    else:
        describeIdea_list = DescribePost.objects.all()
        order = 'normal'
    paginator = Paginator(describeIdea_list, 4)
    page = request.GET.get('page')
    describes = paginator.get_page(page)
    context = { 'describes': describes, 'order': order }
    return render(request, 'describe/list.html', context)
    #####list.html

def describeIdea_create(request):
    if request.method == 'POST':
        new_describeIdea_title = request.POST.get('title')
        new_describe_Idea1 = request.POST.get('idea_1')
        new_describe_Idea2 = request.POST.get('idea_2')
        new_describe_Idea3 = request.POST.get('idea_3')
        new_describe_Idea4 = request.POST.get('idea_4')
        new_describe_Idea5 = request.POST.get('idea_5')
        new_describe_Idea6 = request.POST.get('idea_6')
        new_describe_Idea7 = request.POST.get('idea_7')
        new_describe_Idea8 = request.POST.get('idea_8')
        new_describeIdea_poster =User.objects.get(id=1)
        models.DescribePost.objects.create(title=new_describeIdea_title, 
                                         idea_1=new_describe_Idea1,idea_2=new_describe_Idea2,idea_3=new_describe_Idea3,
                                         idea_4=new_describe_Idea4,idea_5=new_describe_Idea5,idea_6=new_describe_Idea6,
                                         idea_7=new_describe_Idea7,
                                         idea_8=new_describe_Idea8,username=new_describeIdea_poster)
        return redirect("describe:describeIdea_list")
    # get data
    else:
        return render(request, 'describe/create.html')
        ###create.html

def describeIdea_detail(request, id):
    
    describe = DescribePost.objects.get(id=id)
    # view +1
    describe.total_views += 1
    describe.save(update_fields=['total_views'])

    # get comment
    comments = Comment.objects.filter(describe=id)

    # pass template
    
    context = {'describe': describe, 'comments': comments}
    
    return render(request, 'describe/detail.html', context)
    #####detail.html


def describe_delete(request, id):
    
    describe = DescribePost.objects.get(id=id)
   
    describe.delete()
   
    return redirect("describe:describeIdea_list")


@login_required(login_url='/userprofile/login/')

def describeIdea_update(request, id):
    describe=  DescribePost.objects.get(id=id)
    # 过滤非作者的用户
    if request.user != describe.username:
        return HttpResponse("Sorry。you cannot modify this idea")
    
    if request.method == "POST":
        new_describeIdea_title = request.POST.get('title')
        describe.title = new_describeIdea_title
        new_describe_Idea1 = request.POST.get('idea_1')
        new_describe_Idea2 = request.POST.get('idea_2')
        new_describe_Idea3 = request.POST.get('idea_3')
        new_describe_Idea4 = request.POST.get('idea_4')
        new_describe_Idea5 = request.POST.get('idea_5')
        new_describe_Idea6 = request.POST.get('idea_6')
        new_describe_Idea7 = request.POST.get('idea_7')
        new_describe_Idea8 = request.POST.get('idea_8')
        describe.idea_1 = new_describe_Idea1
        describe.idea_2 = new_describe_Idea2
        describe.idea_3 = new_describe_Idea3
        describe.idea_4 = new_describe_Idea4
        describe.idea_5 = new_describe_Idea5
        describe.idea_6 = new_describe_Idea6
        describe.idea_7 = new_describe_Idea7
        describe.idea_8 = new_describe_Idea8
        describe.save()
        return redirect("describe:describeIdea_detail", id=id)
    else:
        context = {'describe': describe}
        return render(request, 'describe/update.html', context)
        ###update.html
        



