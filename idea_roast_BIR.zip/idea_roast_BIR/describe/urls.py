from django.conf.urls import url
from django.urls import path
from . import views


app_name = 'describe'

urlpatterns = [
    url(r'^$', views.describeIdea_list),
    # path to url
    path('describeIdea_list/', views.describeIdea_list, name='describeIdea_list'),
    
    path('describeIdea_detail/<int:id>/', views.describeIdea_detail, name='describeIdea_detail'),
    
    path('describeIdea_create/', views.describeIdea_create, name='describeIdea_create'),
    
    path('describe_delete/<int:id>/', views.describe_delete, name='describe_delete'),
    
    path('describeIdea_update/<int:id>/', views.describeIdea_update, name='describeIdea_update'),
]