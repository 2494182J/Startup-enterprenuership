from django.urls import path
from . import views
app_name = 'comment'

urlpatterns = [
    path('post_comment/<int:describe_id>/', views.post_comment, name='post_comment'),
    path('comment_1/<int:describe_id>/', views.comment_1, name='comment_1'),
    path('comment_2/<int:describe_id>/', views.post_comment, name='comment_2'),
    path('comment_3/<int:describe_id>/', views.post_comment, name='comment_3'),
    path('comment_4/<int:describe_id>/', views.post_comment, name='comment_4'),
    path('comment_5/<int:describe_id>/', views.post_comment, name='comment_5'),
    path('comment_6/<int:describe_id>/', views.post_comment, name='comment_6'),
    path('comment_7/<int:describe_id>/', views.post_comment, name='comment_7'),
    path('comment_8/<int:describe_id>/', views.post_comment, name='comment_8'),
]