from django.shortcuts import render,get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from describe.models import DescribePost
from . import models


@login_required(login_url='/userprofile/login/')
def post_comment(request, describe_id):
    describe = get_object_or_404(DescribePost, id=describe_id)
    if request.method == 'POST':
        #new_comment1 = request.POST.get('Comment_1')
        #new_comment2 = request.POST.get('Comment_2')
        #new_comment3 = request.POST.get('Comment_3')
        #new_comment4 = request.POST.get('Comment_4')
        #new_comment5 = request.POST.get('Comment_5')
        #new_comment6 = request.POST.get('Comment_6')
        #new_comment7 = request.POST.get('Comment_7')
        #new_comment8 = request.POST.get('Comment_8')
        general_comment = request.POST.get('Comment_general')
        new_describe_user = request.user
        models.Comment.objects.create(describe=describe, #Comment_1=new_comment1,Comment_2=new_comment2,Comment_3=new_comment3,
                                     #Comment_4=new_comment4,Comment_5=new_comment5,Comment_6=new_comment6,Comment_7=new_comment7,Comment_8=new_comment8, 
                                     Comment_general=general_comment,user= new_describe_user)
        return redirect(describe)
    else:
        return HttpResponse("This recept POST")

@login_required(login_url='/userprofile/login/')
def comment_1(request, describe_id):
    describe = get_object_or_404(DescribePost, id=describe_id)
    #describe=DescribePost.objects.get(id=id)
    
    render(request,'comment/comment_1.html',)
    if request.method == 'POST':
        new_comment1 = request.POST.get('Comment_1')
        #new_comment2 = request.POST.get('Comment_2')
        #new_comment3 = request.POST.get('Comment_3')
        #new_comment4 = request.POST.get('Comment_4')
        #new_comment5 = request.POST.get('Comment_5')
        #new_comment6 = request.POST.get('Comment_6')
        #new_comment7 = request.POST.get('Comment_7')
        #new_comment8 = request.POST.get('Comment_8')
       
        new_describe_user = request.user
        models.Comment.objects.create(describe=describe, Comment_1=new_comment1,#Comment_2=new_comment2,Comment_3=new_comment3,
                                     #Comment_4=new_comment4,Comment_5=new_comment5,Comment_6=new_comment6,Comment_7=new_comment7,Comment_8=new_comment8, 
                                     user= new_describe_user)
        return redirect('comment/comment_1.html')
    else:
        return HttpResponse("This recept POST")

# Create your views here.
