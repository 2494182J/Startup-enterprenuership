from django.db import models
from django.contrib.auth.models import User
from describe.models import DescribePost
# Create your models here.
class Comment(models.Model):
    describe = models.ForeignKey(DescribePost,on_delete=models.CASCADE,related_name='comments')
    user = models.ForeignKey(User,on_delete=models.CASCADE,related_name='comments')
    Comment_1=models.TextField(blank=True,max_length=500)
    Comment_2=models.TextField(blank=True,max_length=500)
    Comment_3=models.TextField(blank=True,max_length=500)
    Comment_4=models.TextField(blank=True,max_length=500)
    Comment_5=models.TextField(blank=True,max_length=500)
    Comment_6=models.TextField(blank=True,max_length=500)
    Comment_7=models.TextField(blank=True,max_length=500)
    Comment_8=models.TextField(blank=True,max_length=500)
    Comment_general=models.TextField(blank=True,max_length=500)
   ### point_of_idea=models.Field(blank=True,max_length=500)
    created = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ('created',)

    def __str__(self):
        return self.Comment_1[:20]

