from django import forms
from django.contrib.auth.models import User
##login
class UserLoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField()
    

##signup

class UserRegisterForm(forms.ModelForm):
   
    password = forms.CharField()
    password_again = forms.CharField()

    class Meta:
        model = User
        fields = ('username', 'email')


#check password
    def clean_password_again(self):
        data = self.cleaned_data
        if data.get('password') == data.get('password_again'):
            return data.get('password')
        else:
            raise forms.ValidationError("The password is invalid, please enter it again!")
